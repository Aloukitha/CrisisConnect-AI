const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const STATE_PATH = path.join(DATA_DIR, 'state.json');

fs.mkdirSync(DATA_DIR, { recursive: true });

const DEFAULT_AI_SCENARIOS = [
  { severity: 'CRITICAL - LEVEL 4', riverSpeed: '+4.2 in/hr (Cresting at 14.8ft)', summary: 'Heavy cloudburst runoff has overwhelmed the Mill Creek drainage basin. Water levels are rising rapidly along the Riverside District. 3 main arterial bridges are impassable. Secondary earthen levees in Sector 2 show seepage. Priority focus is civilian water rescues and hospital emergency power preservation.', urgentNeeds: ['High-capacity dewatering trash pumps for Central Hospital generator vault', 'Shallow-draft inflatable evacuation boats in Riverside District (Zone A)', 'Clean bottled drinking water and infant formula at North High Shelter'], highRiskLocations: ['Riverside District: 4ft standing water, low-lying homes cut off', 'Central Hospital: Basement utility rooms threatened by sewer backflow', 'Highway 8 Underpass: Stranded transit bus, blocked heavy logistics corridor'] },
  { severity: 'CRITICAL - LEVEL 4', riverSpeed: '+2.8 in/hr (Crest Sustained)', summary: 'Eastern levee berm near Industrial Park is holding but experiencing erosion sloughing on the downstream face. Sump pumps are operating at 95% capacity. Rainfall is transitioning to intermittent squalls, but runoff will maintain peak river surge for the next 4 hours.', urgentNeeds: ['5,000 sandbags and mechanical earthmovers at East Industrial Levee', 'Emergency diesel fuel delivery for auxiliary generators at West Substation', 'Senior citizen transport vans for Elm Street apartment complex'], highRiskLocations: ['East Levee Sector: Saturated soil conditions and seepage points', 'Mill Creek Lowland Rail Yards: Tracks submerged by 2.5ft floodwater', 'South Sector Triage Post: Overwhelmed by minor wound treatments'] },
  { severity: 'HIGH - LEVEL 3', riverSpeed: '-1.1 in/hr (Receding Slowly)', summary: 'Main river surge has peaked and is stabilizing. Downstream tributaries are draining at 1.1 inches per hour. Standing floodwaters remain severely contaminated with municipal runoff. Hazardous debris and downed power lines continue to restrict access across 6 primary transit corridors.', urgentNeeds: ['Industrial water purification units deployed to Valley View community', 'Hazmat inspection team for reported chemical container drift near Pier 4', 'Heavy tree and debris removal winches for Route 12 transit artery'], highRiskLocations: ['Lower Highway 8: Multiple abandoned passenger vehicles and mud deposits', 'Pier 4 Wharf: Loose barges secured, inspection ongoing', 'West Municipal Water Intake: Turbidity levels exceeding safety thresholds'] }
];

const DEFAULT_INCIDENTS = [
  { id: 'inc-1', source: 'Weather Alert', sourceIcon: '⛈️', location: 'Mill Creek Basin / Sector 1', time: '12 mins ago', severity: 'Critical', description: 'Flash Flood Warning escalated to Flash Flood Emergency. River has breached minor flood stage by 3.8 feet.' },
  { id: 'inc-2', source: 'Field Responder', sourceIcon: '🚒', location: 'Riverside District, 4th & River Rd', time: '18 mins ago', severity: 'Critical', description: 'Rapid water rise. 40 residents stranded in 2-story residences. Search & Rescue Boat Team Alpha deploying.' },
  { id: 'inc-3', source: 'Hospital', sourceIcon: '🏥', location: 'Central Hospital (Medical Zone)', time: '24 mins ago', severity: 'High', description: 'Basement transformer and emergency diesel backup generators threatened by 18 inches of flood seepage. Urgent pump request.' },
  { id: 'inc-4', source: 'Government', sourceIcon: '🏛️', location: 'Citywide Metro Area', time: '35 mins ago', severity: 'High', description: 'Mayor and Governor declare Municipal State of Emergency. Mandatory evacuation ordered for flood zones A and B.' },
  { id: 'inc-5', source: 'Citizen', sourceIcon: '📱', location: 'Elm Street & 5th Ave', time: '42 mins ago', severity: 'High', description: 'Elderly care group home basement flooded; water creeping up first-floor stairwell. Power offline.' },
  { id: 'inc-6', source: 'Field Responder', sourceIcon: '🚓', location: 'Highway 8 Underpass', time: '50 mins ago', severity: 'High', description: 'Major arterial road submerged under 5ft of water. 3 vehicles stranded with drivers rescued. Road closed in both directions.' },
  { id: 'inc-7', source: 'Weather Alert', sourceIcon: '🛰️', location: 'Metro Western Ridge', time: '1 hr ago', severity: 'Medium', description: 'Doppler radar indicates secondary precipitation band weakening. Expect 0.75 inches additional rainfall over next 2 hours.' },
  { id: 'inc-8', source: 'Citizen', sourceIcon: '📱', location: 'North Suburbs, Sector 3', time: '1 hr 15 mins ago', severity: 'Low', description: 'Minor street flooding on sidewalk curb; stormwater storm drains gurgling but moving water slowly.' }
];

const DEFAULT_PRIORITY_AREAS = [
  { name: 'Riverside District (Zone A)', riskLevel: 'Critical', peopleAffected: '1,850', requirement: 'Evacuation boats, flotation vests, dry shelter transport', team: 'Search & Rescue Alpha-1', status: 'Active Boat Extraction' },
  { name: 'Central Medical Complex', riskLevel: 'High', peopleAffected: '410 Patients', requirement: 'Dewatering pumps, backup power feed, sterile supplies', team: 'Utility Battalion 4 & EMT Triage', status: 'Active Dewatering' },
  { name: 'East Levee Sector', riskLevel: 'Critical', peopleAffected: '1,250', requirement: 'Sandbag reinforcement, earthmovers, seepage berms', team: 'National Guard Detachment B', status: 'Sandbagging Active' },
  { name: 'Highway 8 Logistics Corridor', riskLevel: 'High', peopleAffected: '620 Commuters', requirement: 'Heavy tow clearance, detour barricades, hazard signage', team: 'State Highway Patrol & DOT', status: 'Route Closed / Diverted' },
  { name: 'North Hills Residential', riskLevel: 'Stable', peopleAffected: '120', requirement: 'Clean bottled water, dry blanket kits, basic medical check', team: 'Volunteer Unit 2', status: 'Monitoring / Safe' }
];

const DEFAULT_RESOURCES = [
  { id: 'res-responders', name: 'Responders', icon: '🛡️', unit: 'Personnel', available: 38, deployed: 142, required: 200 },
  { id: 'res-med', name: 'Medical supplies', icon: '🩹', unit: 'Trauma & Triage Kits', available: 450, deployed: 820, required: 1500 },
  { id: 'res-food', name: 'Food and water', icon: '🍞', unit: 'MRE & Water Packs', available: 1200, deployed: 3400, required: 5000 },
  { id: 'res-vehicles', name: 'Rescue vehicles', icon: '🚤', unit: 'Boats & High-Water Trucks', available: 6, deployed: 22, required: 35 },
  { id: 'res-shelters', name: 'Temporary shelters', icon: '⛺', unit: 'Deployable Units', available: 4, deployed: 8, required: 14 }
];

const DEFAULT_SHELTERS = [
  { id: 'she-1', name: 'North High School Gymnasium', location: '1200 Northridge Way, North Sector', occupancy: 380, capacity: 450, contact: '(555) 019-2831', status: 'Near Capacity' },
  { id: 'she-2', name: 'Civic Community Recreation Center', location: '450 Civic Center Blvd, West Sector', occupancy: 210, capacity: 500, contact: '(555) 014-9922', status: 'Accepting Evacuees' },
  { id: 'she-3', name: 'St. Jude Community Hall', location: '88 Faith Ave, Central District', occupancy: 290, capacity: 300, contact: '(555) 018-4411', status: 'Full' },
  { id: 'she-4', name: 'Westside Sports Fieldhouse', location: '300 Stadium Road, Outer West', occupancy: 150, capacity: 600, contact: '(555) 012-7744', status: 'Accepting Evacuees' }
];

const DEFAULT_TASKS = [
  { id: 'tsk-1', title: 'Deliver 500 emergency rations to Sector 4 Hub', status: 'pending', priority: 'High', assigned: 'Volunteer Logistics', time: '15m ago' },
  { id: 'tsk-2', title: 'Inspect structural stability of Mill Creek Bridge', status: 'pending', priority: 'Critical', assigned: 'Civil Engineering Unit', time: '30m ago' },
  { id: 'tsk-3', title: 'Distribute water purification tablets to North Shelter', status: 'pending', priority: 'Medium', assigned: 'Public Health Team', time: '45m ago' },
  { id: 'tsk-4', title: 'Evacuate 35 residents from Riverside Senior Living', status: 'in-progress', priority: 'Critical', assigned: 'Search & Rescue Alpha-1', time: '25m ago' },
  { id: 'tsk-5', title: 'Install 3 high-capacity submersible pumps at Central Hospital', status: 'in-progress', priority: 'Critical', assigned: 'Utility Battalion 4', time: '40m ago' },
  { id: 'tsk-6', title: 'Operate mobile triage tent at North High School', status: 'in-progress', priority: 'High', assigned: 'Red Cross Medical Team', time: '1h ago' },
  { id: 'tsk-7', title: 'Establish Incident Command Post at City Hall', status: 'completed', priority: 'High', assigned: 'Emergency Management Lead', time: '2h ago' },
  { id: 'tsk-8', title: 'Broadcast Zone A mandatory evacuation alert sirens', status: 'completed', priority: 'Critical', assigned: 'Dispatch Communications', time: '2h ago' },
  { id: 'tsk-9', title: 'Close Highway 8 low-water crossing and set detour signs', status: 'completed', priority: 'Medium', assigned: 'State Highway Patrol', time: '3h ago' }
];

const DEFAULT_ALERTS = [
  { id: 'alt-1', severity: 'Critical', area: 'Riverside District / Lowland Basin', message: 'MANDATORY EVACUATION: Flash flood waters rising rapidly. Evacuate immediately to North High School or Civic Center.', time: '15 mins ago' },
  { id: 'alt-2', severity: 'High', area: 'Highway 8 Corridor', message: 'ROAD CLOSURE: Highway 8 inundated between Exit 14 and Exit 18. Emergency vehicles only.', time: '45 mins ago' },
  { id: 'alt-3', severity: 'Medium', area: 'Citywide Metro', message: 'BOIL WATER ADVISORY: Water treatment plant #2 experiencing high turbidity. Boil tap water for 1 full minute before consumption.', time: '1 hr ago' }
];

const DEFAULT_ACTIVITY_LOG = [
  { id: 'act-1', icon: '🚨', text: 'Mandatory Evacuation broadcasted for Riverside District.', time: '15m ago' },
  { id: 'act-2', icon: '📦', text: 'Allocated 25 Responders to Riverside District (Search & Rescue Alpha-1).', time: '28m ago' },
  { id: 'act-3', icon: '🏠', text: 'Registered Westside Sports Fieldhouse as active shelter (Cap: 600).', time: '50m ago' }
];

const DEFAULT_STATE = {
  currentUser: null,
  aiScenarioIndex: 0,
  resources: JSON.parse(JSON.stringify(DEFAULT_RESOURCES)),
  shelters: JSON.parse(JSON.stringify(DEFAULT_SHELTERS)),
  tasks: JSON.parse(JSON.stringify(DEFAULT_TASKS)),
  alerts: JSON.parse(JSON.stringify(DEFAULT_ALERTS)),
  activityLog: JSON.parse(JSON.stringify(DEFAULT_ACTIVITY_LOG)),
  incidents: JSON.parse(JSON.stringify(DEFAULT_INCIDENTS)),
  priorityAreas: JSON.parse(JSON.stringify(DEFAULT_PRIORITY_AREAS))
};

function loadState() {
  try {
    if (!fs.existsSync(STATE_PATH)) {
      fs.writeFileSync(STATE_PATH, JSON.stringify(DEFAULT_STATE, null, 2));
      return JSON.parse(JSON.stringify(DEFAULT_STATE));
    }

    const data = JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
    return {
      ...JSON.parse(JSON.stringify(DEFAULT_STATE)),
      ...data,
      resources: Array.isArray(data.resources) ? data.resources : JSON.parse(JSON.stringify(DEFAULT_RESOURCES)),
      shelters: Array.isArray(data.shelters) ? data.shelters : JSON.parse(JSON.stringify(DEFAULT_SHELTERS)),
      tasks: Array.isArray(data.tasks) ? data.tasks : JSON.parse(JSON.stringify(DEFAULT_TASKS)),
      alerts: Array.isArray(data.alerts) ? data.alerts : JSON.parse(JSON.stringify(DEFAULT_ALERTS)),
      activityLog: Array.isArray(data.activityLog) ? data.activityLog : JSON.parse(JSON.stringify(DEFAULT_ACTIVITY_LOG)),
      incidents: JSON.parse(JSON.stringify(DEFAULT_INCIDENTS)),
      priorityAreas: JSON.parse(JSON.stringify(DEFAULT_PRIORITY_AREAS))
    };
  } catch (error) {
    console.warn('Loading state failed, restoring defaults:', error.message);
    fs.writeFileSync(STATE_PATH, JSON.stringify(DEFAULT_STATE, null, 2));
    return JSON.parse(JSON.stringify(DEFAULT_STATE));
  }
}

let appState = loadState();

function saveState() {
  fs.writeFileSync(STATE_PATH, JSON.stringify(appState, null, 2));
}

function getDashboardState() {
  return {
    currentUser: appState.currentUser,
    aiScenarioIndex: appState.aiScenarioIndex,
    aiScenario: DEFAULT_AI_SCENARIOS[appState.aiScenarioIndex % DEFAULT_AI_SCENARIOS.length],
    resources: appState.resources,
    shelters: appState.shelters,
    tasks: appState.tasks,
    alerts: appState.alerts,
    activityLog: appState.activityLog,
    incidents: appState.incidents,
    priorityAreas: appState.priorityAreas
  };
}

function resetToDefaults() {
  appState = JSON.parse(JSON.stringify(DEFAULT_STATE));
  saveState();
}

function addActivityLog(icon, text) {
  const newEntry = { id: `act-${Date.now()}`, icon, text, time: 'Just now' };
  appState.activityLog = [newEntry, ...appState.activityLog].slice(0, 25);
  saveState();
  return newEntry;
}

app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(morgan('dev'));

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'CrisisConnect Production API', time: new Date().toISOString() });
});

app.get('/api/state', (req, res) => {
  res.json(getDashboardState());
});

app.post('/api/auth/login', (req, res) => {
  const email = String(req.body.email || 'responder@crisisconnect.local').trim();
  const role = String(req.body.role || 'Field Responder (Ground Operations)').trim();
  appState.currentUser = { email, role, isLoggedIn: true, loginTime: new Date().toLocaleTimeString() };
  addActivityLog('✓', `User ${email} logged in as ${role}.`);
  saveState();
  res.json(getDashboardState());
});

app.post('/api/auth/logout', (req, res) => {
  appState.currentUser = null;
  addActivityLog('⎋', 'Operator signed out of CrisisConnect dashboard.');
  saveState();
  res.json(getDashboardState());
});

app.post('/api/reset', (req, res) => {
  resetToDefaults();
  res.json(getDashboardState());
});

app.post('/api/ai/refresh', (req, res) => {
  appState.aiScenarioIndex = (appState.aiScenarioIndex + 1) % DEFAULT_AI_SCENARIOS.length;
  addActivityLog('✨', 'Refreshed simulated AI situation analysis model.');
  saveState();
  res.json(getDashboardState());
});

app.post('/api/resources/allocate', (req, res) => {
  const { type, quantity, destination, team } = req.body;
  const safeQty = Number(quantity || 0);

  if (!type || !destination || !team || !Number.isFinite(safeQty) || safeQty <= 0) {
    return res.status(400).json({ message: 'Invalid allocation payload.' });
  }

  const resource = appState.resources.find((entry) => entry.name.toLowerCase() === String(type).toLowerCase());
  if (!resource) {
    return res.status(404).json({ message: 'Resource type not found.' });
  }

  const allocated = Math.min(safeQty, resource.available);
  resource.available = Math.max(0, resource.available - allocated);
  resource.deployed = Number(resource.deployed || 0) + allocated;
  addActivityLog('📦', `Allocated ${allocated} ${resource.unit} of ${resource.name} to ${destination} (Unit: ${team}).`);
  saveState();
  res.json(getDashboardState());
});

app.post('/api/shelters', (req, res) => {
  const { name, location, capacity, occupancy, contact } = req.body;
  if (!name || !location || !capacity || !occupancy || !contact) {
    return res.status(400).json({ message: 'All shelter fields are required.' });
  }

  const mappedStatus = (Number(occupancy) / Number(capacity)) * 100 >= 95 ? 'Full' : ((Number(occupancy) / Number(capacity)) * 100 >= 75 ? 'Near Capacity' : 'Accepting Evacuees');
  const profile = { id: `she-${Date.now()}`, name, location, occupancy: Number(occupancy), capacity: Number(capacity), contact, status: mappedStatus };
  appState.shelters.push(profile);
  addActivityLog('🏠', `Registered new emergency shelter: ${name} (Cap: ${profile.capacity}).`);
  saveState();
  res.json(getDashboardState());
});

app.post('/api/tasks/:id/advance', (req, res) => {
  const task = appState.tasks.find((entry) => entry.id === req.params.id);
  if (!task) {
    return res.status(404).json({ message: 'Task not found.' });
  }

  if (task.status === 'pending') {
    task.status = 'in-progress';
    addActivityLog('📋', `Task "${task.title}" started by ${task.assigned}.`);
  } else if (task.status === 'in-progress') {
    task.status = 'completed';
    addActivityLog('📋', `Task "${task.title}" marked as Completed.`);
  }

  saveState();
  res.json(getDashboardState());
});

app.post('/api/alerts', (req, res) => {
  const { severity, area, message } = req.body;
  if (!severity || !area || !message) {
    return res.status(400).json({ message: 'Alert severity, area, and message are required.' });
  }

  appState.alerts.unshift({ id: `alt-${Date.now()}`, severity, area, message, time: 'Just now' });
  addActivityLog('🚨', `Dispatched ${severity} Alert to ${area}: "${message.substring(0, 40)}..."`);
  saveState();
  res.json(getDashboardState());
});

app.post('/api/activity/clear', (req, res) => {
  appState.activityLog = [];
  saveState();
  res.json(getDashboardState());
});

app.use(express.static(path.join(ROOT, 'public')));

app.get('*', (req, res) => {
  res.sendFile(path.join(ROOT, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`CrisisConnect production API listening on http://localhost:${PORT}`);
});
