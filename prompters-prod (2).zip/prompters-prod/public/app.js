const state = {
  currentUser: null,
  aiScenario: null,
  resources: [],
  shelters: [],
  tasks: [],
  alerts: [],
  activityLog: [],
  incidents: [],
  priorityAreas: []
};

const DEFAULT_SITES = [
  { id: 'site-1', name: 'National Weather Service', category: 'Weather', icon: '⛈️', desc: 'Official real-time precipitation radar, severe storm warnings, and flash flood alerts.', url: 'https://www.weather.gov' },
  { id: 'site-2', name: 'USGS National Water Dashboard', category: 'Weather', icon: '🌊', desc: 'Interactive streamflow, river water levels, flood crest stages, and rain gauge telemetry.', url: 'https://dashboard.waterdata.usgs.gov' },
  { id: 'site-3', name: 'FEMA Disaster Assistance', category: 'Emergency', icon: '🏛️', desc: 'Federal emergency coordination, national situation reports, and community recovery aid.', url: 'https://www.fema.gov' },
  { id: 'site-4', name: 'American Red Cross Shelters', category: 'Emergency', icon: '🏠', desc: 'Open shelter directory, mass care feeding locations, and reunification services.', url: 'https://www.redcross.org' },
  { id: 'site-5', name: 'OpenStreetMap Humanitarian GIS', category: 'Maps', icon: '🗺️', desc: 'Collaborative disaster mapping, road closures, impassable bridges, and satellite overlays.', url: 'https://www.openstreetmap.org' },
  { id: 'site-6', name: 'CDC Emergency Preparedness', category: 'Medical', icon: '🏥', desc: 'Public health crisis guidelines, contaminated water management, and triage manuals.', url: 'https://www.cdc.gov' },
  { id: 'site-7', name: 'CrisisConnect AI Dashboard', category: 'Emergency', icon: '⚡', desc: 'Tactical local coordination dashboard with incident logs, shelter capacity, and task Kanban.', url: '/' },
  { id: 'site-8', name: 'FlightAware Rescue Flight Radar', category: 'Maps', icon: '🚁', desc: 'Live airborne emergency helicopter tracking, search and rescue flight coordinates.', url: 'https://flightaware.com' }
];

const API = {
  async get(path) {
    const response = await fetch(path, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      throw new Error('Request failed');
    }
    return response.json();
  },

  async post(path, payload = {}) {
    const response = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.message || 'Request failed');
    }
    return data;
  }
};

function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add('fade-out');
    setTimeout(() => toast.remove(), 350);
  }, 2800);
}

function initClock() {
  const clock = document.getElementById('live-clock');
  if (!clock) return;
  const update = () => {
    const now = new Date();
    clock.textContent = now.toLocaleString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  };
  update();
  setInterval(update, 1000);
}

function renderKpis() {
  const grid = document.getElementById('kpi-grid');
  if (!grid) return;

  const incidents = state.incidents.length;
  const responders = state.resources.find((r) => r.name === 'Responders')?.deployed || 142;
  const totalCapacity = state.shelters.reduce((sum, s) => sum + Number(s.capacity), 0);
  const totalOccupancy = state.shelters.reduce((sum, s) => sum + Number(s.occupancy), 0);
  const openCount = state.shelters.filter((s) => s.status !== 'Full').length;
  const freeBeds = Math.max(0, totalCapacity - totalOccupancy);
  const occupancyPct = totalCapacity ? Math.round((totalOccupancy / totalCapacity) * 100) : 0;

  const cards = [
    { icon: '🚨', label: 'Active Incidents', value: incidents, sub: '3 Critical', extra: '↑ 4 reported in past 30 mins' },
    { icon: '👥', label: 'People Displaced / Impacted', value: '4,250', sub: 'High Impact', extra: 'Evacuation orders active in 2 sectors' },
    { icon: '🛡️', label: 'Responders Deployed', value: responders, sub: '38 Standby', extra: 'National Guard, EMT, Fire & Rescue' },
    { icon: '🏠', label: 'Shelter Capacity', value: `${freeBeds} Beds`, sub: `${openCount} Open Facilities`, extra: `${totalOccupancy} of ${totalCapacity} occupied (${occupancyPct}%)` }
  ];

  grid.innerHTML = cards.map((card) => `
    <article class="kpi-card">
      <div class="kpi-icon">${card.icon}</div>
      <div class="kpi-content">
        <span class="kpi-label">${card.label}</span>
        <div class="kpi-value">${card.value}</div>
        <div class="kpi-micro">${card.sub}</div>
        <div class="kpi-micro">${card.extra}</div>
      </div>
    </article>
  `).join('');
}

function renderAiAnalysis() {
  const container = document.getElementById('ai-analysis');
  if (!container || !state.aiScenario) return;
  const scenario = state.aiScenario;
  const critical = scenario.severity.includes('CRITICAL') ? 'badge-critical' : 'badge-warning';

  container.innerHTML = `
    <div class="ai-topline">
      <div class="meta-box ${critical}">
        <small>Overall Severity</small>
        <strong>${scenario.severity}</strong>
      </div>
      <div class="meta-box">
        <small>River Inundation Velocity</small>
        <strong>${scenario.riverSpeed}</strong>
      </div>
      <div class="meta-box">
        <small>Last AI Assessment</small>
        <strong>${new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</strong>
      </div>
    </div>
    <div class="ai-columns">
      <div class="ai-block">
        <h4>Executive Summary</h4>
        <p>${scenario.summary}</p>
      </div>
      <div class="ai-block">
        <h4>🚨 Most Urgent Operational Needs</h4>
        <ul>${scenario.urgentNeeds.map((item) => `<li>${item}</li>`).join('')}</ul>
      </div>
      <div class="ai-block">
        <h4>⚠️ High-Risk Identified Locations</h4>
        <ul>${scenario.highRiskLocations.map((item) => `<li>${item}</li>`).join('')}</ul>
      </div>
    </div>
    <div class="ai-block">
      <h4>🤖 CrisisConnect Neural Core v2.4 (Simulated Engine)</h4>
      <div><strong>Confidence Score:</strong> 94.8%</div>
    </div>
  `;
}

function renderIncidents() {
  const feed = document.getElementById('incident-feed');
  if (!feed) return;
  const severityFilter = document.getElementById('filter-severity')?.value || 'All';
  const sourceFilter = document.getElementById('filter-source')?.value || 'All';

  const filtered = state.incidents.filter((incident) => {
    const severityMatch = severityFilter === 'All' || incident.severity === severityFilter;
    const sourceMatch = sourceFilter === 'All' || incident.source === sourceFilter;
    return severityMatch && sourceMatch;
  });

  feed.innerHTML = filtered.map((incident) => {
    const badgeClass = incident.severity === 'Critical' ? 'badge-danger' : incident.severity === 'High' ? 'badge-warning' : incident.severity === 'Medium' ? 'badge-info' : 'badge-success';
    return `
      <article class="incident-card">
        <div class="incident-card-top">
          <span class="incident-source">${incident.sourceIcon} ${incident.source}</span>
          <span class="badge ${badgeClass}">${incident.severity}</span>
        </div>
        <h4 class="incident-location">📍 ${incident.location}</h4>
        <p class="incident-desc">${incident.description}</p>
        <div class="incident-card-bottom">
          <span>🕒 Reported: ${incident.time}</span>
          <a class="badge badge-info" href="/hub.html" target="_blank" rel="noopener noreferrer">Open Source ↗</a>
        </div>
      </article>
    `;
  }).join('') || '<div class="incident-card">No incidents match the selected filters.</div>';
}

function renderPriorityAreas() {
  const body = document.getElementById('priority-areas-body');
  const count = document.getElementById('priority-area-count');
  if (!body) return;
  if (count) count.textContent = `${state.priorityAreas.length} Monitored Sectors`;
  body.innerHTML = state.priorityAreas.map((area) => {
    const badge = area.riskLevel === 'Critical' ? 'badge-danger' : area.riskLevel === 'High' ? 'badge-warning' : 'badge-success';
    const label = area.riskLevel === 'Critical' ? '🔴 Critical' : area.riskLevel === 'High' ? '🟠 High Priority' : '🟢 Stable / Safe';
    return `
      <tr>
        <td><strong>${area.name}</strong></td>
        <td><span class="badge ${badge}">${label}</span></td>
        <td><strong>${area.peopleAffected}</strong></td>
        <td>${area.requirement}</td>
        <td><span class="badge badge-info">${area.team}</span></td>
        <td><em>${area.status}</em></td>
      </tr>
    `;
  }).join('');
}

function renderResources() {
  const container = document.getElementById('resource-cards');
  if (!container) return;
  container.innerHTML = state.resources.map((resource) => `
    <article class="resource-card">
      <div class="res-header">
        <span class="res-icon">${resource.icon}</span>
        <h4 class="res-title">${resource.name}</h4>
      </div>
      <div class="res-stats-list">
        <div class="res-stat-row"><span>Available:</span><span class="stat-num avail">${resource.available}</span></div>
        <div class="res-stat-row"><span>Deployed:</span><span class="stat-num">${resource.deployed}</span></div>
        <div class="res-stat-row"><span>Required:</span><span class="stat-num req">${resource.required}</span></div>
        <div class="res-stat-row"><span>Unit:</span><span class="stat-num">${resource.unit}</span></div>
      </div>
      <button class="btn btn-outline small-action" data-action="allocate-resource" data-name="${resource.name}">Deploy / Allocate</button>
    </article>
  `).join('');
}

function renderShelters() {
  const container = document.getElementById('shelter-list');
  if (!container) return;

  container.innerHTML = state.shelters.map((shelter) => {
    const pct = shelter.capacity ? Math.min(100, Math.round((shelter.occupancy / shelter.capacity) * 100)) : 0;
    let fillClass = 'fill-safe';
    let badgeClass = 'badge-success';
    if (pct >= 95 || shelter.status === 'Full') { fillClass = 'fill-critical'; badgeClass = 'badge-danger'; }
    else if (pct >= 75 || shelter.status === 'Near Capacity') { fillClass = 'fill-warning'; badgeClass = 'badge-warning'; }

    return `
      <article class="shelter-card">
        <div class="shelter-top">
          <h4 class="shelter-name">🏠 ${shelter.name}</h4>
          <span class="badge ${badgeClass}">${shelter.status}</span>
        </div>
        <span class="shelter-loc">📍 ${shelter.location}</span>
        <div class="progress-wrap">
          <div class="progress-header"><span>Occupancy Rate</span><strong>${shelter.occupancy} / ${shelter.capacity} (${pct}%)</strong></div>
          <div class="progress-bar-bg"><div class="progress-bar-fill ${fillClass}" style="width: ${pct}%"></div></div>
        </div>
        <div class="shelter-details">
          <div class="shelter-detail-row"><span>Available Spaces:</span><span class="detail-val">${Math.max(0, shelter.capacity - shelter.occupancy)} Beds</span></div>
          <div class="shelter-detail-row"><span>Emergency Contact:</span><span class="detail-val">${shelter.contact}</span></div>
        </div>
      </article>
    `;
  }).join('');
}

function renderTasks() {
  const pending = document.getElementById('tasks-pending');
  const progress = document.getElementById('tasks-in-progress');
  const done = document.getElementById('tasks-completed');
  if (!pending || !progress || !done) return;

  const countPending = document.getElementById('count-pending');
  const countProgress = document.getElementById('count-in-progress');
  const countCompleted = document.getElementById('count-completed');

  const groups = {
    pending: state.tasks.filter((task) => task.status === 'pending'),
    'in-progress': state.tasks.filter((task) => task.status === 'in-progress'),
    completed: state.tasks.filter((task) => task.status === 'completed')
  };

  if (countPending) countPending.textContent = groups.pending.length;
  if (countProgress) countProgress.textContent = groups['in-progress'].length;
  if (countCompleted) countCompleted.textContent = groups.completed.length;

  const renderCard = (task) => {
    const badgeClass = task.priority === 'Critical' ? 'badge-danger' : task.priority === 'High' ? 'badge-warning' : 'badge-info';
    const actionText = task.status === 'pending' ? 'Start Task ➔' : task.status === 'in-progress' ? 'Mark Complete ✓' : '✓ Done';
    return `
      <article class="task-card">
        <div class="task-card-header">
          <span class="badge ${badgeClass}">${task.priority}</span>
          <span class="task-card-meta">${task.time}</span>
        </div>
        <h4 class="task-card-title">${task.title}</h4>
        <div class="task-card-meta">👤 ${task.assigned}</div>
        <div class="task-actions">
          <button class="btn btn-outline small-action" data-action="advance-task" data-id="${task.id}">${actionText}</button>
        </div>
      </article>
    `;
  };

  pending.innerHTML = groups.pending.map(renderCard).join('') || '<div class="task-card">No pending tasks</div>';
  progress.innerHTML = groups['in-progress'].map(renderCard).join('') || '<div class="task-card">No tasks in progress</div>';
  done.innerHTML = groups.completed.map(renderCard).join('') || '<div class="task-card">No completed tasks</div>';
}

function renderAlerts() {
  const list = document.getElementById('alerts-list');
  if (!list) return;
  list.innerHTML = state.alerts.map((alert) => {
    const badgeClass = alert.severity === 'Critical' ? 'badge-danger' : alert.severity === 'High' ? 'badge-warning' : 'badge-info';
    return `
      <div class="alert-feed-item alert-${alert.severity.toLowerCase()}">
        <div class="alert-item-header">
          <span class="alert-item-area">📍 ${alert.area}</span>
          <span class="badge ${badgeClass}">${alert.severity}</span>
        </div>
        <p class="alert-item-msg">${alert.message}</p>
        <span class="alert-item-time">🕒 Dispatched: ${alert.time}</span>
      </div>
    `;
  }).join('');
}

function renderActivityLog() {
  const list = document.getElementById('activity-log');
  if (!list) return;
  list.innerHTML = state.activityLog.map((item) => `
    <div class="activity-item">
      <span class="activity-icon">${item.icon}</span>
      <div class="activity-content">
        <p class="activity-text">${item.text}</p>
        <span class="activity-time">🕒 ${item.time}</span>
      </div>
    </div>
  `).join('');
}

function renderAuthState() {
  const loginScreen = document.getElementById('login-screen');
  const dashboard = document.getElementById('dashboard-container');
  if (!loginScreen || !dashboard) return;

  if (state.currentUser && state.currentUser.isLoggedIn) {
    loginScreen.classList.add('hidden');
    dashboard.classList.remove('hidden');
    const email = document.getElementById('header-user-email');
    const role = document.getElementById('header-user-role');
    const avatar = document.getElementById('header-avatar');
    if (email) email.textContent = state.currentUser.email;
    if (role) role.textContent = state.currentUser.role;
    if (avatar) avatar.textContent = state.currentUser.role.split(' ').map((word) => word[0]).join('').slice(0, 2) || 'OP';
  } else {
    loginScreen.classList.remove('hidden');
    dashboard.classList.add('hidden');
  }
}

function render() {
  renderAuthState();
  renderKpis();
  renderAiAnalysis();
  renderIncidents();
  renderPriorityAreas();
  renderResources();
  renderShelters();
  renderTasks();
  renderAlerts();
  renderActivityLog();
}

async function loadDashboard() {
  try {
    const data = await API.get('/api/state');
    state.currentUser = data.currentUser;
    state.aiScenario = data.aiScenario;
    state.resources = data.resources;
    state.shelters = data.shelters;
    state.tasks = data.tasks;
    state.alerts = data.alerts;
    state.activityLog = data.activityLog;
    state.incidents = data.incidents;
    state.priorityAreas = data.priorityAreas;
    render();
  } catch (error) {
    showToast('Unable to connect to the backend.', 'error');
  }
}

async function handleLogin(event) {
  event.preventDefault();
  const email = document.getElementById('login-email')?.value || 'responder@crisisconnect.local';
  const role = document.getElementById('login-role')?.value || 'Field Responder (Ground Operations)';

  try {
    const data = await API.post('/api/auth/login', { email, role });
    state.currentUser = data.currentUser;
    state.aiScenario = data.aiScenario;
    state.resources = data.resources;
    state.shelters = data.shelters;
    state.tasks = data.tasks;
    state.alerts = data.alerts;
    state.activityLog = data.activityLog;
    state.incidents = data.incidents;
    state.priorityAreas = data.priorityAreas;
    render();
    showToast(`Welcome back, ${role}. Emergency mode active.`, 'success');
  } catch (error) {
    showToast('Login failed. Please try again.', 'error');
  }
}

async function handleLogout() {
  try {
    const data = await API.post('/api/auth/logout', {});
    state.currentUser = data.currentUser;
    state.aiScenario = data.aiScenario;
    state.resources = data.resources;
    state.shelters = data.shelters;
    state.tasks = data.tasks;
    state.alerts = data.alerts;
    state.activityLog = data.activityLog;
    state.incidents = data.incidents;
    state.priorityAreas = data.priorityAreas;
    render();
    showToast('Logged out of coordination terminal.', 'info');
  } catch (error) {
    showToast('Logout failed.', 'error');
  }
}

async function refreshAi() {
  try {
    const data = await API.post('/api/ai/refresh', {});
    state.currentUser = data.currentUser;
    state.aiScenario = data.aiScenario;
    state.resources = data.resources;
    state.shelters = data.shelters;
    state.tasks = data.tasks;
    state.alerts = data.alerts;
    state.activityLog = data.activityLog;
    state.incidents = data.incidents;
    state.priorityAreas = data.priorityAreas;
    render();
    showToast('AI Situation Analysis updated with latest intelligence feed.', 'info');
  } catch (error) {
    showToast('Unable to refresh AI analysis.', 'error');
  }
}

async function resetDemo() {
  try {
    const data = await API.post('/api/reset', {});
    state.currentUser = data.currentUser;
    state.aiScenario = data.aiScenario;
    state.resources = data.resources;
    state.shelters = data.shelters;
    state.tasks = data.tasks;
    state.alerts = data.alerts;
    state.activityLog = data.activityLog;
    state.incidents = data.incidents;
    state.priorityAreas = data.priorityAreas;
    render();
    showToast('System reset to default demo scenario.', 'info');
  } catch (error) {
    showToast('Reset failed.', 'error');
  }
}

async function allocateResource(payload = null) {
  const type = payload?.type || document.getElementById('resource-type')?.value || 'Responders';
  let quantity = payload?.quantity || document.getElementById('resource-quantity')?.value || 1;
  let destination = payload?.destination || document.getElementById('resource-destination')?.value || 'Riverside District';
  let team = payload?.team || document.getElementById('resource-team')?.value || 'Rescue Unit';

  if (!payload) {
    const selectedType = prompt('Resource type:', type) || type;
    const selectedQty = Number(prompt('Allocation quantity:', String(quantity)) || quantity);
    const selectedDest = prompt('Destination:', destination) || destination;
    const selectedTeam = prompt('Assigned team:', team) || team;
    quantity = selectedQty || quantity;
    destination = selectedDest;
    team = selectedTeam;
    type = selectedType;
  }

  try {
    const data = await API.post('/api/resources/allocate', { type, quantity: Number(quantity), destination, team });
    state.resources = data.resources;
    state.activityLog = data.activityLog;
    render();
    showToast(`Successfully allocated ${quantity} units to ${destination}!`, 'success');
  } catch (error) {
    showToast('Resource allocation failed.', 'error');
  }
}

async function addShelter() {
  let name = document.getElementById('shelter-name')?.value?.trim();
  let location = document.getElementById('shelter-location')?.value?.trim();
  let capacity = document.getElementById('shelter-capacity')?.value;
  let occupancy = document.getElementById('shelter-occupancy')?.value;
  let contact = document.getElementById('shelter-contact')?.value?.trim();

  if (!name || !location || !capacity || !occupancy || !contact) {
    name = prompt('Shelter name:', 'North High School Gymnasium') || 'North High School Gymnasium';
    location = prompt('Shelter location:', '1200 Northridge Way, North Sector') || '1200 Northridge Way, North Sector';
    capacity = Number(prompt('Capacity:', '450') || '450');
    occupancy = Number(prompt('Current occupancy:', '380') || '380');
    contact = prompt('Emergency contact:', '(555) 019-2831') || '(555) 019-2831';
  }

  try {
    const data = await API.post('/api/shelters', { name, location, capacity: Number(capacity), occupancy: Number(occupancy), contact });
    state.shelters = data.shelters;
    state.activityLog = data.activityLog;
    render();
    showToast(`Emergency shelter registered: ${name}!`, 'success');
  } catch (error) {
    showToast('Shelter registration failed.', 'error');
  }
}

async function sendAlert() {
  let severity = document.getElementById('alert-severity')?.value || 'Critical';
  let area = document.getElementById('alert-area')?.value?.trim();
  let message = document.getElementById('alert-message')?.value?.trim();

  if (!area || !message) {
    severity = prompt('Alert severity (Critical / High / Medium):', severity) || severity;
    area = prompt('Target area:', 'Riverside District / Lowland Basin') || 'Riverside District / Lowland Basin';
    message = prompt('Alert message:', 'MANDATORY EVACUATION: Move to the nearest safe shelter immediately.') || 'MANDATORY EVACUATION: Move to the nearest safe shelter immediately.';
  }

  try {
    const data = await API.post('/api/alerts', { severity, area, message });
    state.alerts = data.alerts;
    state.activityLog = data.activityLog;
    render();
    showToast('Emergency alert dispatched across responder channels!', 'success');
  } catch (error) {
    showToast('Alert dispatch failed.', 'error');
  }
}

async function advanceTask(taskId) {
  try {
    const data = await API.post(`/api/tasks/${taskId}/advance`, {});
    state.tasks = data.tasks;
    state.activityLog = data.activityLog;
    render();
    showToast('Task status updated.', 'info');
  } catch (error) {
    showToast('Unable to update task.', 'error');
  }
}

async function clearLog() {
  try {
    const data = await API.post('/api/activity/clear', {});
    state.activityLog = data.activityLog;
    render();
    showToast('Activity log cleared.', 'info');
  } catch (error) {
    showToast('Unable to clear activity log.', 'error');
  }
}

function bindEvents() {
  document.getElementById('login-form')?.addEventListener('submit', handleLogin);
  document.getElementById('logout-button')?.addEventListener('click', handleLogout);
  document.getElementById('refresh-ai-button')?.addEventListener('click', refreshAi);
  document.getElementById('reset-demo-button')?.addEventListener('click', resetDemo);
  document.getElementById('send-alert-button')?.addEventListener('click', sendAlert);
  document.getElementById('allocate-resource-button')?.addEventListener('click', allocateResource);
  document.getElementById('register-shelter-button')?.addEventListener('click', addShelter);
  document.getElementById('clear-log-button')?.addEventListener('click', clearLog);
  document.getElementById('send-alert-panel-button')?.addEventListener('click', sendAlert);
  document.getElementById('allocate-resource-panel-button')?.addEventListener('click', allocateResource);
  document.getElementById('register-shelter-panel-button')?.addEventListener('click', addShelter);
  document.getElementById('filter-severity')?.addEventListener('change', renderIncidents);
  document.getElementById('filter-source')?.addEventListener('change', renderIncidents);
  document.getElementById('reset-filters-button')?.addEventListener('click', () => {
    const severity = document.getElementById('filter-severity');
    const source = document.getElementById('filter-source');
    if (severity) severity.value = 'All';
    if (source) source.value = 'All';
    renderIncidents();
  });

  document.body.addEventListener('click', (event) => {
    const actionTarget = event.target.closest('[data-action]');
    if (actionTarget) {
      const action = actionTarget.dataset.action;
      if (action === 'advance-task') {
        advanceTask(actionTarget.dataset.id);
      }
      if (action === 'allocate-resource') {
        const name = actionTarget.dataset.name || 'Responders';
        allocateResource({ type: name, quantity: 10, destination: 'Riverside District', team: 'Rescue Unit' });
      }
    }

    const mapPin = event.target.closest('.map-pin');
    if (mapPin) {
      const inspector = document.getElementById('map-inspector');
      const title = document.getElementById('inspector-title');
      const desc = document.getElementById('inspector-desc');
      if (title) title.textContent = `📍 ${mapPin.dataset.title} — ${mapPin.dataset.subtitle}`;
      if (desc) desc.textContent = mapPin.dataset.desc;
      if (inspector) inspector.classList.remove('hidden');
    }

    if (event.target.id === 'close-map-inspector') {
      const inspector = document.getElementById('map-inspector');
      if (inspector) inspector.classList.add('hidden');
    }
  });

  const hubSearch = document.getElementById('hub-search');
  const filterButtons = document.querySelectorAll('[data-filter]');
  if (hubSearch) {
    hubSearch.addEventListener('input', renderHubSites);
  }
  filterButtons.forEach((button) => {
    button.addEventListener('click', () => {
      filterButtons.forEach((btn) => btn.classList.toggle('active', btn === button));
      renderHubSites();
    });
  });

  const openSelected = document.getElementById('open-selected');
  if (openSelected) {
    openSelected.addEventListener('click', () => {
      const selected = document.querySelectorAll('.site-card input:checked');
      const urls = Array.from(selected).map((checkbox) => checkbox.closest('.site-card')?.dataset.url).filter(Boolean);
      if (!urls.length) {
        showToast('Select at least one website to open.', 'info');
        return;
      }
      urls.forEach((url) => window.open(url, '_blank', 'noopener,noreferrer'));
    });
  }

  const customSiteButton = document.getElementById('add-custom-site');
  if (customSiteButton) {
    customSiteButton.addEventListener('click', () => {
      const url = prompt('Enter a website URL to add to the launchpad:', 'https://');
      if (!url) return;
      const formatted = /^https?:\/\//i.test(url) ? url : `https://${url}`;
      const item = {
        id: `custom-${Date.now()}`,
        name: 'Custom Site',
        category: 'Custom',
        icon: '🔗',
        desc: 'User-added disaster response web resource.',
        url: formatted
      };
      const saved = JSON.parse(localStorage.getItem('custom-sites') || '[]');
      saved.push(item);
      localStorage.setItem('custom-sites', JSON.stringify(saved));
      renderHubSites();
      showToast('Custom website added to the launchpad.', 'success');
    });
  }
}

function renderHubSites() {
  const grid = document.getElementById('site-grid');
  if (!grid) return;

  const searchValue = (document.getElementById('hub-search')?.value || '').toLowerCase();
  const activeFilter = document.querySelector('.chip.active')?.dataset.filter || 'all';
  const storedCustom = JSON.parse(localStorage.getItem('custom-sites') || '[]');
  const sites = [...DEFAULT_SITES, ...storedCustom];

  const filtered = sites.filter((site) => {
    const matchesSearch = !searchValue || [site.name, site.category, site.desc, site.url].join(' ').toLowerCase().includes(searchValue);
    const matchesFilter = activeFilter === 'all' || site.category === activeFilter || (activeFilter === 'Custom' && site.category === 'Custom');
    return matchesSearch && matchesFilter;
  });

  grid.innerHTML = filtered.map((site) => `
    <article class="site-card" data-url="${site.url}">
      <div class="site-card-header">
        <div class="site-meta">
          <span class="site-icon">${site.icon}</span>
          <div>
            <span class="site-category">${site.category}</span>
            <h3 class="site-name">${site.name}</h3>
          </div>
        </div>
        <label class="site-check"><input type="checkbox" /></label>
      </div>
      <p class="site-description">${site.desc}</p>
      <div class="site-footer">
        <span class="site-url">${site.url}</span>
        <a class="site-link" href="${site.url}" target="_blank" rel="noopener noreferrer">Open in New Tab ↗</a>
      </div>
    </article>
  `).join('');
}

document.addEventListener('DOMContentLoaded', async () => {
  initClock();
  bindEvents();
  renderHubSites();
  await loadDashboard();
});
